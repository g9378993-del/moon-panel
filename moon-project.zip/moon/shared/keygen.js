const { customAlphabet } = require("nanoid");
const { db, logAction } = require("../server/db");

// Alphabet lisible (sans 0/O/1/I pour éviter les confusions à la lecture)
const alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
const nanoid = customAlphabet(alphabet, 5);

function generateKeyString(prefix = "MOON") {
  return `${prefix}-${nanoid()}-${nanoid()}-${nanoid()}`;
}

/**
 * Crée une nouvelle clé en base.
 * @param {object} opts
 * @param {number|null} opts.durationDays - null = lifetime
 * @param {string} opts.note
 * @param {string} opts.createdBy - Discord ID
 */
function createKey({ durationDays = null, note = "", createdBy }) {
  let keyValue;
  // évite (très improbable) les collisions
  do {
    keyValue = generateKeyString();
  } while (db.prepare("SELECT 1 FROM keys WHERE key_value = ?").get(keyValue));

  db.prepare(
    `INSERT INTO keys (key_value, status, note, duration_days, created_by)
     VALUES (?, 'unused', ?, ?, ?)`
  ).run(keyValue, note, durationDays, createdBy);

  logAction("genkey", createdBy, keyValue, note);
  return getKey(keyValue);
}

function getKey(keyValue) {
  return db.prepare("SELECT * FROM keys WHERE key_value = ?").get(keyValue);
}

/**
 * Attribue une clé à un utilisateur Discord (whitelist) et l'active.
 */
function whitelistKey({ keyValue, discordId, hwid = null, actorId }) {
  const key = getKey(keyValue);
  if (!key) return { ok: false, reason: "not_found" };
  if (key.status === "revoked") return { ok: false, reason: "revoked" };
  if (key.status === "active" && key.discord_id && key.discord_id !== discordId) {
    return { ok: false, reason: "already_claimed" };
  }

  const now = new Date();
  let expiresAt = null;
  if (key.duration_days) {
    const exp = new Date(now.getTime() + key.duration_days * 86400000);
    expiresAt = exp.toISOString();
  }

  db.prepare(
    `UPDATE keys SET status = 'active', discord_id = ?, hwid = ?, activated_at = ?, expires_at = ?
     WHERE key_value = ?`
  ).run(discordId, hwid, now.toISOString(), expiresAt, keyValue);

  logAction("whitelist", actorId, keyValue, `discord_id=${discordId}`);
  return { ok: true, key: getKey(keyValue) };
}

function revokeKey({ keyValue, actorId }) {
  const key = getKey(keyValue);
  if (!key) return { ok: false, reason: "not_found" };

  db.prepare(
    `UPDATE keys SET status = 'revoked', revoked_at = ? WHERE key_value = ?`
  ).run(new Date().toISOString(), keyValue);

  logAction("revoke", actorId, keyValue, null);
  return { ok: true, key: getKey(keyValue) };
}

function checkExpiry(key) {
  if (key.status === "active" && key.expires_at) {
    if (new Date(key.expires_at).getTime() < Date.now()) {
      db.prepare(`UPDATE keys SET status = 'expired' WHERE key_value = ?`).run(key.key_value);
      return { ...key, status: "expired" };
    }
  }
  return key;
}

function stats() {
  const total = db.prepare("SELECT COUNT(*) c FROM keys").get().c;
  const active = db.prepare("SELECT COUNT(*) c FROM keys WHERE status='active'").get().c;
  const unused = db.prepare("SELECT COUNT(*) c FROM keys WHERE status='unused'").get().c;
  const revoked = db.prepare("SELECT COUNT(*) c FROM keys WHERE status='revoked'").get().c;
  const expired = db.prepare("SELECT COUNT(*) c FROM keys WHERE status='expired'").get().c;
  return { total, active, unused, revoked, expired };
}

module.exports = { createKey, getKey, whitelistKey, revokeKey, checkExpiry, stats };
