const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { whitelistKey } = require("../../shared/keygen");
const { isStaff } = require("../permissions");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("whitelist")
    .setDescription("Attribuer une clé à un utilisateur")
    .addStringOption((opt) =>
      opt.setName("cle").setDescription("La clé à attribuer").setRequired(true)
    )
    .addUserOption((opt) =>
      opt.setName("utilisateur").setDescription("Utilisateur à whitelist").setRequired(true)
    ),

  async execute(interaction) {
    if (!isStaff(interaction.member)) {
      return interaction.reply({
        content: "⛔ Tu n'as pas la permission d'utiliser cette commande.",
        ephemeral: true,
      });
    }

    const keyValue = interaction.options.getString("cle").trim();
    const user = interaction.options.getUser("utilisateur");

    const result = whitelistKey({
      keyValue,
      discordId: user.id,
      actorId: interaction.user.id,
    });

    if (!result.ok) {
      const messages = {
        not_found: "❌ Cette clé n'existe pas.",
        revoked: "❌ Cette clé a été révoquée.",
        already_claimed: "❌ Cette clé est déjà attribuée à un autre utilisateur.",
      };
      return interaction.reply({
        content: messages[result.reason] || "❌ Erreur inconnue.",
        ephemeral: true,
      });
    }

    const embed = new EmbedBuilder()
      .setColor(0x7cf5c4)
      .setTitle("✅ Utilisateur whitelist")
      .addFields(
        { name: "Clé", value: `\`${keyValue}\`` },
        { name: "Utilisateur", value: `<@${user.id}>`, inline: true },
        {
          name: "Expire",
          value: result.key.expires_at
            ? `<t:${Math.floor(new Date(result.key.expires_at).getTime() / 1000)}:F>`
            : "Jamais",
          inline: true,
        }
      )
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  },
};
