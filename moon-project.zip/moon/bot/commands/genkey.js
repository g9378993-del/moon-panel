const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const { createKey } = require("../../shared/keygen");
const { isStaff } = require("../permissions");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("genkey")
    .setDescription("Générer une nouvelle clé de licence Moon")
    .addIntegerOption((opt) =>
      opt
        .setName("duree")
        .setDescription("Durée de validité en jours (laisser vide = à vie)")
        .setMinValue(1)
    )
    .addStringOption((opt) =>
      opt.setName("note").setDescription("Note interne (ex: nom du client, produit...)")
    ),

  async execute(interaction) {
    if (!isStaff(interaction.member)) {
      return interaction.reply({
        content: "⛔ Tu n'as pas la permission d'utiliser cette commande.",
        ephemeral: true,
      });
    }

    const duration = interaction.options.getInteger("duree");
    const note = interaction.options.getString("note") || "—";

    const key = createKey({
      durationDays: duration,
      note,
      createdBy: interaction.user.id,
    });

    const embed = new EmbedBuilder()
      .setColor(0x7c8cff)
      .setTitle("🌙 Nouvelle clé générée")
      .addFields(
        { name: "Clé", value: `\`${key.key_value}\`` },
        { name: "Durée", value: duration ? `${duration} jour(s)` : "À vie", inline: true },
        { name: "Note", value: note, inline: true }
      )
      .setFooter({ text: "Moon • Gardez cette clé confidentielle" })
      .setTimestamp();

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
