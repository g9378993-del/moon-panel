const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { revokeKey } = require("../../shared/keygen");
const { isStaff } = require("../permissions");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("revoke")
    .setDescription("Révoquer une clé de licence")
    .addStringOption((opt) =>
      opt.setName("cle").setDescription("La clé à révoquer").setRequired(true)
    ),

  async execute(interaction) {
    if (!isStaff(interaction.member)) {
      return interaction.reply({
        content: "⛔ Tu n'as pas la permission d'utiliser cette commande.",
        ephemeral: true,
      });
    }

    const keyValue = interaction.options.getString("cle").trim();
    const result = revokeKey({ keyValue, actorId: interaction.user.id });

    if (!result.ok) {
      return interaction.reply({ content: "❌ Cette clé n'existe pas.", ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0xff7a93)
      .setTitle("🚫 Clé révoquée")
      .setDescription(`\`${keyValue}\` a été révoquée avec succès.`)
      .setTimestamp();

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
