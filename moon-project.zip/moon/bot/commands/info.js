const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { getKey, checkExpiry } = require("../../shared/keygen");

const STATUS_LABEL = {
  unused: "⚪ Non utilisée",
  active: "🟢 Active",
  revoked: "🔴 Révoquée",
  expired: "🟠 Expirée",
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName("info")
    .setDescription("Voir le statut d'une clé")
    .addStringOption((opt) =>
      opt.setName("cle").setDescription("La clé à consulter").setRequired(true)
    ),

  async execute(interaction) {
    const keyValue = interaction.options.getString("cle").trim();
    let key = getKey(keyValue);

    if (!key) {
      return interaction.reply({ content: "❌ Cette clé n'existe pas.", ephemeral: true });
    }
    key = checkExpiry(key);

    const embed = new EmbedBuilder()
      .setColor(0x7c8cff)
      .setTitle("🌙 Statut de la clé")
      .addFields(
        { name: "Clé", value: `\`${key.key_value}\`` },
        { name: "Statut", value: STATUS_LABEL[key.status] || key.status, inline: true },
        {
          name: "Attribuée à",
          value: key.discord_id ? `<@${key.discord_id}>` : "—",
          inline: true,
        },
        {
          name: "Expire",
          value: key.expires_at
            ? `<t:${Math.floor(new Date(key.expires_at).getTime() / 1000)}:F>`
            : key.status === "unused"
            ? "—"
            : "Jamais",
          inline: true,
        },
        { name: "Note", value: key.note || "—" }
      )
      .setTimestamp();

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
