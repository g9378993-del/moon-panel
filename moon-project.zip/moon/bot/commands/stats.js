const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { stats } = require("../../shared/keygen");
const { isStaff } = require("../permissions");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("stats")
    .setDescription("Statistiques globales des clés Moon"),

  async execute(interaction) {
    if (!isStaff(interaction.member)) {
      return interaction.reply({
        content: "⛔ Tu n'as pas la permission d'utiliser cette commande.",
        ephemeral: true,
      });
    }

    const s = stats();
    const embed = new EmbedBuilder()
      .setColor(0x7c8cff)
      .setTitle("🌙 Statistiques Moon")
      .addFields(
        { name: "Total", value: `${s.total}`, inline: true },
        { name: "Actives", value: `${s.active}`, inline: true },
        { name: "Non utilisées", value: `${s.unused}`, inline: true },
        { name: "Révoquées", value: `${s.revoked}`, inline: true },
        { name: "Expirées", value: `${s.expired}`, inline: true }
      )
      .setTimestamp();

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
