function isStaff(member) {
  if (!member) return false;
  // Les administrateurs du serveur ont toujours accès
  if (member.permissions?.has("Administrator")) return true;

  const staffRoleIds = (process.env.STAFF_ROLE_IDS || "")
    .split(",")
    .map((id) => id.trim())
    .filter(Boolean);

  if (staffRoleIds.length === 0) return false;
  return member.roles?.cache?.some((role) => staffRoleIds.includes(role.id));
}

module.exports = { isStaff };
