# 🌙 Moon — Bot Discord + Panel de gestion de licences

Bot Discord et panel web pour générer, attribuer et révoquer des clés de licence, avec les commandes `/genkey`, `/whitelist`, `/revoke`, `/info`, `/stats`.

## 1. Créer l'application Discord

1. Va sur https://discord.com/developers/applications
2. Ton bot utilise déjà l'ID d'application **`1536530514314403850`** (déjà configuré dans `.env.example`).
3. Dans l'onglet **Bot** : clique sur "Reset Token" puis copie le token → colle-le dans `DISCORD_TOKEN`.
4. Dans l'onglet **OAuth2 → General** : copie le **Client Secret** → colle-le dans `DISCORD_CLIENT_SECRET`.
5. Toujours dans **OAuth2 → General**, ajoute cette URL de redirection :
   `http://localhost:3000/auth/discord/callback` (ou ton domaine en production).
6. Dans **Bot**, active si besoin l'intégration nécessaire (aucun intent privilégié n'est requis ici).

### Inviter le bot sur ton serveur

Utilise ce lien (déjà généré avec ton Client ID et les permissions nécessaires) :

```
https://discord.com/api/oauth2/authorize?client_id=1536530514314403850&permissions=84992&scope=bot%20applications.commands
```

## 2. Installation

```bash
cd moon
npm install
cp .env.example .env
```

Remplis ensuite `.env` :
- `DISCORD_TOKEN` : le token de ton bot
- `DISCORD_CLIENT_SECRET` : le secret OAuth2
- `DISCORD_GUILD_ID` : l'ID de ton serveur (clic droit sur le serveur → Copier l'ID, mode développeur activé)
- `STAFF_ROLE_IDS` : l'ID du/des rôle(s) autorisés à utiliser `/genkey`, `/whitelist`, `/revoke` et accéder au panel
- `SESSION_SECRET` : une chaîne aléatoire longue (ex: générée avec `openssl rand -hex 32`)

## 3. Déployer les commandes slash

```bash
npm run deploy-commands
```

Comme `DISCORD_GUILD_ID` est renseigné, les commandes apparaissent instantanément sur ton serveur de test. Pour un déploiement global (tous les serveurs, propagation ~1h), retire `DISCORD_GUILD_ID` du `.env` avant de relancer la commande.

## 4. Lancer le bot et le panel

Dans deux terminaux séparés :

```bash
npm run bot      # démarre le bot Discord
npm start        # démarre le serveur web (panel + API) sur http://localhost:3000
```

Ou en une seule commande (nécessite `concurrently`, déjà dans les devDependencies) :

```bash
npm run dev
```

## 5. Utilisation

- **Landing page publique** : `http://localhost:3000/` — c'est le lien à partager (voir référencement Google ci-dessous).
- **Dashboard admin** : `http://localhost:3000/dashboard.html` — connexion via Discord, réservé aux membres ayant un rôle listé dans `STAFF_ROLE_IDS`.
- **Commandes Discord** : `/genkey`, `/whitelist`, `/revoke`, `/info`, `/stats`.

## 6. Personnalisation du thème "Moon"

Toutes les couleurs sont centralisées dans `panel/css/style.css`, en haut du fichier (`:root { ... }`) :
- `--accent` / `--accent-soft` : bleu-lune principal
- `--success`, `--danger` : statuts des clés
- `--bg-void`, `--bg-panel` : fonds

Change ces valeurs pour ajuster toute l'identité visuelle d'un coup.

## 7. Déploiement en production

Le projet est un simple serveur Node.js + SQLite : il tourne sur n'importe quel hébergeur qui supporte Node (Railway, Render, VPS, etc.). Points à vérifier :

- Mets `PANEL_URL` et `DISCORD_REDIRECT_URI` à jour avec ton vrai domaine (`https://...`).
- Ajoute cette même URL de redirection dans le Developer Portal Discord (OAuth2 → Redirects).
- Utilise un process manager (`pm2`) pour garder le bot et le serveur actifs :
  ```bash
  pm2 start server/index.js --name moon-panel
  pm2 start bot/index.js --name moon-bot
  ```
- Mets un certificat HTTPS (obligatoire pour l'OAuth2 Discord en production, via un reverse proxy type Nginx/Caddy).

## 8. Faire apparaître le lien sur Google

Un site n'est jamais indexé instantanément — voici les étapes concrètes une fois le site en ligne sur ton vrai domaine :

1. **Remplace le domaine placeholder** `votredomaine.exemple` par ton vrai nom de domaine dans `panel/index.html` (balises `og:*`, `canonical`), `panel/robots.txt` et `panel/sitemap.xml`.
2. **Google Search Console** (https://search.google.com/search-console) :
   - Ajoute ta propriété (ton domaine).
   - Vérifie la propriété (via balise HTML, DNS ou fichier).
   - Soumets `https://tondomaine.com/sitemap.xml` dans l'onglet "Sitemaps".
   - Utilise "Inspection de l'URL" → "Demander une indexation" sur ta page d'accueil pour accélérer le passage du robot.
3. **Contenu et backlinks** : Google indexe plus vite et classe mieux un site qui a déjà des liens entrants (annonce sur ton serveur Discord, réseaux sociaux, forums pertinents). Un lien depuis un site déjà indexé aide beaucoup.
4. **Vérifie que rien ne bloque l'indexation** : le `robots.txt` fourni autorise `/` mais bloque `/dashboard.html` et `/api/` (comportement voulu, pour ne pas indexer le panel d'admin).
5. Compte généralement **quelques jours à quelques semaines** avant d'apparaître dans les résultats — aucun outil ne peut le forcer instantanément, mais soumettre le sitemap et demander l'indexation via Search Console est ce qui accélère le plus le processus.

## Structure du projet

```
moon/
├── bot/            → bot Discord (discord.js)
│   └── commands/   → /genkey, /whitelist, /revoke, /info, /stats
├── server/         → API Express + auth OAuth2 Discord + service du panel
├── panel/          → landing page publique + dashboard admin (HTML/CSS/JS)
├── shared/         → logique de génération/gestion des clés (partagée bot ↔ serveur)
└── .env.example
```
