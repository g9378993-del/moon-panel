const express = require("express");
const router = express.Router();
const fetch = require("node-fetch");

const {
  DISCORD_CLIENT_ID,
  DISCORD_CLIENT_SECRET,
  DISCORD_REDIRECT_URI,
  STAFF_ROLE_IDS,
  DISCORD_GUILD_ID,
} = process.env;

router.get("/discord", (req, res) => {
  const params = new URLSearchParams({
    client_id: DISCORD_CLIENT_ID,
    redirect_uri: DISCORD_REDIRECT_URI,
    response_type: "code",
    scope: "identify guilds.members.read",
  });
  res.redirect(`https://discord.com/oauth2/authorize?${params.toString()}`);
});

router.get("/discord/callback", async (req, res) => {
  const { code } = req.query;
  if (!code) return res.redirect("/?error=missing_code");

  try {
    // 1. Échange du code contre un token
    const tokenRes = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: DISCORD_CLIENT_ID,
        client_secret: DISCORD_CLIENT_SECRET,
        grant_type: "authorization_code",
        code,
        redirect_uri: DISCORD_REDIRECT_URI,
      }),
    });
    const tokenData = await tokenRes.json();
    if (!tokenData.access_token) throw new Error("token_exchange_failed");

    // 2. Récupération du profil utilisateur
    const userRes = await fetch("https://discord.com/api/users/@me", {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });
    const userData = await userRes.json();

    // 3. Vérification du rôle staff sur le serveur (si configuré)
    let isStaff = false;
    const staffRoleIds = (STAFF_ROLE_IDS || "").split(",").map((s) => s.trim()).filter(Boolean);

    if (DISCORD_GUILD_ID && staffRoleIds.length > 0) {
      const memberRes = await fetch(
        `https://discord.com/api/users/@me/guilds/${DISCORD_GUILD_ID}/member`,
        { headers: { Authorization: `Bearer ${tokenData.access_token}` } }
      );
      if (memberRes.ok) {
        const memberData = await memberRes.json();
        isStaff = (memberData.roles || []).some((r) => staffRoleIds.includes(r));
      }
    }

    req.session.user = {
      id: userData.id,
      username: userData.username,
      avatar: userData.avatar
        ? `https://cdn.discordapp.com/avatars/${userData.id}/${userData.avatar}.png`
        : null,
      isStaff,
    };

    res.redirect("/dashboard.html");
  } catch (err) {
    console.error(err);
    res.redirect("/?error=auth_failed");
  }
});

router.post("/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

module.exports = router;
