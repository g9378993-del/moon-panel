const express = require("express");
const router = express.Router();
const { db } = require("../db");
const { createKey, whitelistKey, revokeKey, checkExpiry, stats } = require("../../shared/keygen");

function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "not_authenticated" });
  next();
}

function requireStaff(req, res, next) {
  if (!req.session.user?.isStaff) return res.status(403).json({ error: "forbidden" });
  next();
}

// --- Session / utilisateur courant ---
router.get("/me", (req, res) => {
  if (!req.session.user) return res.json({ authenticated: false });
  res.json({ authenticated: true, user: req.session.user });
});

// --- Statistiques ---
router.get("/stats", requireAuth, requireStaff, (req, res) => {
  res.json(stats());
});

// --- Liste des clés (paginée, filtrable) ---
router.get("/keys", requireAuth, requireStaff, (req, res) => {
  const { status, search } = req.query;
  const limit = Math.min(parseInt(req.query.limit) || 50, 200);
  const offset = parseInt(req.query.offset) || 0;

  let query = "SELECT * FROM keys WHERE 1=1";
  const params = [];

  if (status) {
    query += " AND status = ?";
    params.push(status);
  }
  if (search) {
    query += " AND (key_value LIKE ? OR note LIKE ? OR discord_id LIKE ?)";
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }

  query += " ORDER BY created_at DESC LIMIT ? OFFSET ?";
  params.push(limit, offset);

  const rows = db.prepare(query).all(...params).map(checkExpiry);
  res.json({ keys: rows });
});

// --- Génération d'une clé ---
router.post("/keys", requireAuth, requireStaff, (req, res) => {
  const { durationDays, note } = req.body;
  const key = createKey({
    durationDays: durationDays || null,
    note: note || "",
    createdBy: req.session.user.id,
  });
  res.json({ key });
});

// --- Whitelist (attribution) ---
router.post("/keys/:keyValue/whitelist", requireAuth, requireStaff, (req, res) => {
  const { discordId, hwid } = req.body;
  const result = whitelistKey({
    keyValue: req.params.keyValue,
    discordId,
    hwid,
    actorId: req.session.user.id,
  });
  if (!result.ok) return res.status(400).json(result);
  res.json(result);
});

// --- Révocation ---
router.post("/keys/:keyValue/revoke", requireAuth, requireStaff, (req, res) => {
  const result = revokeKey({ keyValue: req.params.keyValue, actorId: req.session.user.id });
  if (!result.ok) return res.status(400).json(result);
  res.json(result);
});

// --- Journal d'audit ---
router.get("/audit", requireAuth, requireStaff, (req, res) => {
  const rows = db
    .prepare("SELECT * FROM audit_log ORDER BY created_at DESC LIMIT 100")
    .all();
  res.json({ log: rows });
});

module.exports = router;
