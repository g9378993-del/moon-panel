require("dotenv").config();
const path = require("path");
const express = require("express");
const session = require("express-session");
const cookieParser = require("cookie-parser");

const app = express();

app.use(express.json());
app.use(cookieParser());
app.use(
  session({
    secret: process.env.SESSION_SECRET || "moon-dev-secret",
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 * 24 * 7 }, // 7 jours
  })
);

app.use("/auth", require("./routes/auth"));
app.use("/api", require("./routes/api"));

// Sert le panel (fichiers statiques + landing page publique)
app.use(express.static(path.join(__dirname, "..", "panel")));

// robots.txt / sitemap.xml à la racine pour le référencement
app.get("/robots.txt", (req, res) => {
  res.type("text/plain").sendFile(path.join(__dirname, "..", "panel", "robots.txt"));
});
app.get("/sitemap.xml", (req, res) => {
  res.type("application/xml").sendFile(path.join(__dirname, "..", "panel", "sitemap.xml"));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🌙 Panel Moon en ligne sur http://localhost:${PORT}`);
});
