const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

const dbPath = process.env.DATABASE_PATH || path.join(__dirname, "moon.sqlite");
fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const db = new Database(dbPath);
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS keys (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  key_value     TEXT UNIQUE NOT NULL,
  status        TEXT NOT NULL DEFAULT 'unused',   -- unused | active | revoked | expired
  note          TEXT,
  duration_days INTEGER,                          -- NULL = lifetime
  created_by    TEXT,                              -- Discord ID de celui qui a genkey
  discord_id    TEXT,                               -- Discord ID à qui la clé est attribuée (whitelist)
  hwid          TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  activated_at  TEXT,
  expires_at    TEXT,
  revoked_at    TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  action      TEXT NOT NULL,
  actor_id    TEXT,
  target_key  TEXT,
  detail      TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_keys_status ON keys(status);
CREATE INDEX IF NOT EXISTS idx_keys_discord_id ON keys(discord_id);
`);

function logAction(action, actorId, targetKey, detail) {
  db.prepare(
    `INSERT INTO audit_log (action, actor_id, target_key, detail) VALUES (?, ?, ?, ?)`
  ).run(action, actorId || null, targetKey || null, detail || null);
}

module.exports = { db, logAction };
