const app = document.getElementById("app");

const STATUS_LABEL = {
  unused: "Non utilisée",
  active: "Active",
  revoked: "Révoquée",
  expired: "Expirée",
};

function fmtDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleDateString("fr-FR", { day: "2-digit", month: "short", year: "numeric" });
}

function badge(status) {
  return `<span class="badge ${status}"><span class="badge-dot"></span>${STATUS_LABEL[status] || status}</span>`;
}

async function api(path, opts = {}) {
  const res = await fetch(`/api${path}`, {
    headers: { "Content-Type": "application/json" },
    ...opts,
  });
  return res.json();
}

async function init() {
  const me = await api("/me");
  if (!me.authenticated) return renderTemplate("tpl-login");
  if (!me.user.isStaff) return renderTemplate("tpl-forbidden");
  renderDashboard();
}

function renderTemplate(id) {
  app.innerHTML = "";
  app.appendChild(document.getElementById(id).content.cloneNode(true));
}

async function renderDashboard() {
  renderTemplate("tpl-dash");

  document.getElementById("logout-btn").addEventListener("click", async () => {
    await fetch("/auth/logout", { method: "POST" });
    location.href = "/";
  });

  document.querySelectorAll(".side-link[data-view]").forEach((el) => {
    el.addEventListener("click", () => switchView(el.dataset.view));
  });

  document.getElementById("open-genkey").addEventListener("click", openGenkeyModal);
  document.getElementById("search-input").addEventListener("input", debounce(loadKeys, 300));
  document.getElementById("status-filter").addEventListener("change", loadKeys);

  await loadStats();
  await loadKeys();
}

function switchView(view) {
  document.querySelectorAll(".side-link[data-view]").forEach((el) =>
    el.classList.toggle("active", el.dataset.view === view)
  );
  document.getElementById("view-keys").classList.toggle("hidden", view !== "keys");
  document.getElementById("view-audit").classList.toggle("hidden", view !== "audit");
  document.getElementById("view-title").textContent =
    view === "keys" ? "Clés de licence" : "Journal d'activité";
  document.getElementById("open-genkey").classList.toggle("hidden", view !== "keys");
  if (view === "audit") loadAudit();
}

async function loadStats() {
  const s = await api("/stats");
  const grid = document.getElementById("stat-grid");
  const cards = [
    ["Total", s.total],
    ["Actives", s.active],
    ["Non utilisées", s.unused],
    ["Révoquées", s.revoked],
    ["Expirées", s.expired],
  ];
  grid.innerHTML = cards
    .map(([label, num]) => `<div class="stat-card"><div class="num">${num}</div><div class="label">${label}</div></div>`)
    .join("");
}

async function loadKeys() {
  const search = document.getElementById("search-input").value;
  const status = document.getElementById("status-filter").value;
  const params = new URLSearchParams();
  if (search) params.set("search", search);
  if (status) params.set("status", status);

  const { keys } = await api(`/keys?${params.toString()}`);
  const tbody = document.getElementById("keys-tbody");

  if (!keys.length) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:var(--moon-dim); padding:32px;">Aucune clé trouvée.</td></tr>`;
    return;
  }

  tbody.innerHTML = keys
    .map(
      (k) => `
      <tr>
        <td><span class="key-code">${k.key_value}</span></td>
        <td>${badge(k.status)}</td>
        <td>${k.discord_id ? `<code>${k.discord_id}</code>` : "—"}</td>
        <td>${k.note || "—"}</td>
        <td>${fmtDate(k.created_at)}</td>
        <td style="text-align:right; white-space:nowrap;">
          ${k.status !== "revoked" && !k.discord_id ? `<button class="btn btn-ghost btn-sm" data-action="whitelist" data-key="${k.key_value}">Attribuer</button>` : ""}
          ${k.status !== "revoked" ? `<button class="btn btn-danger btn-sm" data-action="revoke" data-key="${k.key_value}">Révoquer</button>` : ""}
        </td>
      </tr>`
    )
    .join("");

  tbody.querySelectorAll('[data-action="revoke"]').forEach((btn) =>
    btn.addEventListener("click", () => revokeKey(btn.dataset.key))
  );
  tbody.querySelectorAll('[data-action="whitelist"]').forEach((btn) =>
    btn.addEventListener("click", () => openWhitelistModal(btn.dataset.key))
  );
}

async function loadAudit() {
  const { log } = await api("/audit");
  const tbody = document.getElementById("audit-tbody");
  tbody.innerHTML = log
    .map(
      (l) => `
      <tr>
        <td>${l.action}</td>
        <td>${l.actor_id ? `<code>${l.actor_id}</code>` : "—"}</td>
        <td>${l.target_key ? `<span class="key-code">${l.target_key}</span>` : "—"}</td>
        <td>${l.detail || "—"}</td>
        <td>${fmtDate(l.created_at)}</td>
      </tr>`
    )
    .join("");
}

async function revokeKey(keyValue) {
  if (!confirm(`Révoquer la clé ${keyValue} ?`)) return;
  await api(`/keys/${encodeURIComponent(keyValue)}/revoke`, { method: "POST" });
  await loadStats();
  await loadKeys();
}

function openGenkeyModal() {
  renderModal("tpl-modal-genkey");
  document.getElementById("genkey-cancel").addEventListener("click", closeModal);
  document.getElementById("genkey-submit").addEventListener("click", async () => {
    const duration = document.getElementById("genkey-duration").value;
    const note = document.getElementById("genkey-note").value;
    await api("/keys", {
      method: "POST",
      body: JSON.stringify({ durationDays: duration ? parseInt(duration) : null, note }),
    });
    closeModal();
    await loadStats();
    await loadKeys();
  });
}

function openWhitelistModal(keyValue) {
  renderModal("tpl-modal-whitelist");
  document.getElementById("whitelist-key-label").textContent = keyValue;
  document.getElementById("whitelist-cancel").addEventListener("click", closeModal);
  document.getElementById("whitelist-submit").addEventListener("click", async () => {
    const discordId = document.getElementById("whitelist-discordid").value.trim();
    if (!discordId) return;
    const result = await api(`/keys/${encodeURIComponent(keyValue)}/whitelist`, {
      method: "POST",
      body: JSON.stringify({ discordId }),
    });
    if (result.ok === false) {
      alert("Erreur : " + result.reason);
      return;
    }
    closeModal();
    await loadKeys();
  });
}

function renderModal(tplId) {
  closeModal();
  const node = document.getElementById(tplId).content.cloneNode(true);
  document.body.appendChild(node);
}

function closeModal() {
  document.querySelectorAll(".modal-overlay").forEach((el) => el.remove());
}

function debounce(fn, ms) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

init();
